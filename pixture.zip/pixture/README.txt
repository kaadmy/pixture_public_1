=======================================================
 _____
| ___ \                                        _______
||   || ++ \\    // ___||___ ||    || || ____ / _____ \
||___||     \\  //  |__||__| ||    || ||/___| |/     \|
|_____/ ||   \\//      ||    ||    || | /     ||_____/|
||      ||   //\\      ||    ||    || ||      ||______/
||      ||  //  \\     ||    ||____|| ||      |\_______
||      || //    \\    ||     \____/  ||      \_______|

=======================================================
By Kaadmy
Inspiration by Kenney(kenney.nl)

Note: Do not use mapgen v6, it is not supported and will fail. Use v5 or v7 instead.

Mapgen:
    Seeds that give good results with mapgen v7:
        "wl":
            Usually spawns you in a savanna with a tall mountain and village nearby.
            Some grassland and wastelands.
        "pt":
            Usually spawns you near a tall mountain and deep forests.
            Use the chatcommand "/teleport 200 5 150" to get to a flat forested area.
        "qwerty":
            Usually spawns you in some flat grasslands that have a high change of
              spawning villages nearby.
        "beach":
            Usually spawns you on a small beach area with gravel beaches and cliffs nearby,
              and a village also spawns at the same place.
	"wilderness":
            At 590, 30, 350 and -100, 11, 200
            Wilderness biome and a village

Special credits:
    Extra-special credit to Kenney(kenney.nl) for the inspiration,
      most of the graphics design. (All images are of my own creation but based
      off Kenney's), and the overall feeling.
    Sounds in the default mod are all by Kenney(CC0)
    All textures/models by Kaadmy(WTFPL)

Asset license: all WTFPL, CC0, or GPL(The GPL ones I want replaced with WTFPL preferably),
  see per-mod READMEs.
Source license: all WTFPL or LGPLv2.1, see per-mod READMEs.
