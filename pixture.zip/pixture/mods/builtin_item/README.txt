Builtin item mod
================
By PilzAdam
Tweaked by Kaadmy, for Pixture

Items are now destroyed by lava and flow with water.

Source license: WTFPL
