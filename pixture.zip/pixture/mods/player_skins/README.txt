Player skins mod
================
By Kaadmy, for Pixture

Adds changeable player skins

Asset license: WTFPL
Source license: WTFPL
