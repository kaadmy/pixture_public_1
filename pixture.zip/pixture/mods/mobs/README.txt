Mobs mod
========
By PilzAdam, KrupnovPavel, Zeg9, TenPlus1
Tweaked by Kaadmy, for Pixture

Asset license: WTFPL
Source License:
    api.lua: MIT
    sheep.lua: MIT
    boar.lua: MIT
    npc.lua: MIT
    mineturtle.lua: WTFPL
    crafts.lua: WTFPL
	
