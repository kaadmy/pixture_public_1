Crafting guide mod
==================

By Kaadmy, for Pixture

This mod adds a crafting guide in your inventory.

Asset license: WTFPL
Source license: WTFPL
