Utility mod
===========
By Kaadmy, for Pixture

Source license: WTFPL
