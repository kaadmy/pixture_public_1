TNT mod
=======
By PilzAdam and ShadowNinja
Tweaked by Kaadmy, for Pixture

Adds explodable TNT
Place a block of TNT, then click on it with flint and steel

Source license: WTFPL
Asset license: WTFPL
