Give initial stuff mod
======================
By Kaadmy

Source license: WTFPL
