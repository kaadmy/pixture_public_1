--
-- Nav mod
-- By Kaadmy, for Pixture
--

nav = {}

dofile(minetest.get_modpath("nav").."/map.lua")
dofile(minetest.get_modpath("nav").."/compass.lua")
