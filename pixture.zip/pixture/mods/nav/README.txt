Navigation mod
==============
By Kaadmy, for Pixture

Navigation, compass and waypoint API

Asset license: WTFPL
Source license: WTFPL
