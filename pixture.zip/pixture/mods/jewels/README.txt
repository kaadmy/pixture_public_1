Jewels mod
==========
By Kaadmy

Adds tools with different stats via a Jeweler's Workbench.

Asset license: WTFPL
Source license: WTFPL
