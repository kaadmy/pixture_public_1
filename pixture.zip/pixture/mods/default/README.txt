Default mod
===========
By Kaadmy, for Pixture

Adds the required stuff to run

WARNING: This mod will not be compatible with existing mods, tons of stuff has been renamed!

Sound license: CC0
Texture license: WTFPL
Model license: WTFPL
Source license: WTFPL(Some code from minetest_game's default mod, which is LGPL2.1+)
