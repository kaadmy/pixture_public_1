Private message mod
===================
By Kaadmy, for Pixture

Send private messages that save until the player rejoins
Private messages are cleared on server restart

Source license: WTFPL
