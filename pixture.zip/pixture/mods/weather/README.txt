Weather mod
===========
By Kaadmy, for Pixture

Texture license: WTFPL
Sound license:
    weather_night.ogg: CC0
    weather_storm.ogg: GPLv2(Replace this, I want CC0/WTFPL-only assets)
    weather_snowstorm.ogg: GPLv2(Replace this, I want CC0/WTFPL-only assets)
Source license: WTFPL
