Playerlist mod
==================
By Kaadmy, for Pixture

Adds player lists(recent/current).

Use the chatcommand "/plist" to show current players
Use the chatcommand "/precent" to show players that have connected in the last hour

Source license: WTFPL
