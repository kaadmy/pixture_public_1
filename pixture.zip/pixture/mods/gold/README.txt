Gold mod
========
By Kaadmy, for Pixture

Trading/currency mod; required by mobs

Asset license: WTFPL
Source license: WTFPL
