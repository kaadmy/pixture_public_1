Farming mod
===========
By Kaadmy, for Pixture

Place wheat/cotton seeds near water
When they become stage 4, they can be harvested

Asset license: WTFPL
Source license: WTFPL
