Armor mod
=========

By Kaadmy, for Pixture

Adds craftable and wearable armor

Asset license: WTFPL
Source code license: WTFPL
