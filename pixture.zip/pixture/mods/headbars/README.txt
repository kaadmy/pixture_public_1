Headbars mod
============
By Kaadmy, for Pixture

Puts a health bar above players

Source license: WTFPL
