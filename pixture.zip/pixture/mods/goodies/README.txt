Goodies mod
===========
By Kaadmy

Adds goodies so you can auto-fill chests with cool stuff

Source license: WTFPL
