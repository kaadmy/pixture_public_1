Drop items on die mod
=====================
By Kaadmy, for Pixture

Players drop their inventory when they die

Source license: WTFPL
