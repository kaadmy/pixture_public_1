Locks mod
=========
By Kaadmy, for Pixture

Adds locked stuff, like locked chests.

Source license: WTFPL
Asset license: WTFPL
