Testing mod
===========
By Kaadmy

Adds some testing stuff

Source license: WTFPL
