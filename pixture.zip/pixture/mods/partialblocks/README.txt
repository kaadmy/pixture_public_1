Partial blocks mod
==================
By Kaadmy, for Pixture

Adds partial blocks, like slabs, stairs and such.

Asset license: WTFPL
Source license: WTFPL
