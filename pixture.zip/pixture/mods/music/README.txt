Music player mod
================
By Kaadmy, for Pixture

Music license:
    music_catsong: Dan Knoflicek(CC0)
    music_wonderful_nightmare.ogg: SpiderDave(CC0)
    music_greyarms.ogg: Tozan(CC0)

Texture license: WTFPL
Source License: WTFPL
