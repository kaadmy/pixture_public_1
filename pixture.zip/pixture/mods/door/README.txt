Door mod
========
By PilzAdam
Tweaked by Kaadmy, for Pixture

Right-click doors to open/close them

Asset license: WTFPL
Source license: WTFPL
