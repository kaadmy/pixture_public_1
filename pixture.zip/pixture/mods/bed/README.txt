Beds mod
========
By PilzAdam, thefamilygrog66
Tweaked by Kadmy, for Pixture

Right-click a bed to sleep, right-click again to get out.

Asset license: WTFPL
Source licens: WTFPL
